import sofia.micro.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class Colony extends HomeBase
{
    //~ Fields ................................................................

    private int food;
    private int count;
    private QueensChamber chamber;
    private Hive hive ;

    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Colony object.
     */
    public Colony()
    {
        super();

        hive = new Hive();
        this.add(hive, 9, 3);
        chamber = new QueensChamber();
        this.add(chamber, 0, 3);
        
        food = 10;

        setActorChoices(
            HarvesterAnt.class,
            ThrowerAnt.class,
            WallAnt.class,
            FireAnt.class,
            HungryAnt.class);
    }

    //~ Methods ...............................................................
    // ----------------------------------------------------------
    /**
     * Add an ant to the screen when a specific location is clicked.
     * This method is automatically called while the simulation is
     * running, whenever the user clicks on (or taps on) a location
     * in the colony (one that isn't covered by an actor already).
     * 
     * @param x The x-coordinate of the click
     * @param y The y-coordinate of the click
     */
    public void onTouchDown(int x, int y)
    {

        Ant selectedAnt = (Ant) newActorOfSelectedType();

        if (selectedAnt.getFoodCost() <= food )
        {   

            if ((x <= 8) && (y <= 5))
            {
                this.add(selectedAnt, x, y);
                this.consumeFood(selectedAnt.getFoodCost());
            }           

        }
    }

    /**
     * Returns the ants stomach contents
     * @return The stomach contents of the ants
     */

    public int getFood()
    {
        return food;
    }

    public void addFood(int a)
    {
        food = food + a;
    }

    public void consumeFood(int b)
    {
        food = food - b;     
    }

    @Override    
    public void act()
    {
        super.act();
        
        if ((this.getObjects(Bee.class).size() == 0) && (hive.getBees() == 0))
        {
            this.win();
        }

        if (chamber.beesInChamber())
        {
            this.lose();
        }

    }
}
