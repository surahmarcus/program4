import sofia.micro.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class HungryAnt extends Ant
{
    //~ Fields ................................................................

    private int numberOfAct;

    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new HungryAnt object.
     */
    public HungryAnt()
    {
        super(5, 1);
        numberOfAct = 240;
    }


    //~ Methods ...............................................................

    public void act()
    {                    
        
        if (numberOfAct < 240)
        {
            numberOfAct++ ;
        }
       
        else if (this.getOneIntersectingObject(Bee.class) != null)
        {             
            this.getWorld().remove(getOneIntersectingObject(Bee.class));
            numberOfAct = 0;            
        }  
        
    }


}
