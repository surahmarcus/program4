import sofia.micro.*;
import java.util.List;
import java.util.ArrayList; 

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class FireAnt extends Ant
{
    //~ Fields ................................................................
    private int h;
    
    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new FireAnt object.
     */
    public FireAnt()
    {
        super(4, 1);
    }


    //~ Methods ...............................................................

    @Override    
    public void injure(int n)
    {
        
        if (this.getHealth() -n <= 0)
        {
           List<Bee> neighbors;
            neighbors = this.getNeighbors(1, true, Bee.class);
            for (Bee bee : neighbors)
            {                
                bee.injure(3);
            }
            
            if (this.getOneIntersectingObject(Bee.class) != null)
            {
                this.getWorld().remove(getOneIntersectingObject(Bee.class));
            }
            
        }
        super.injure(n);
    }

    public void act()
    {
        
    }

}
