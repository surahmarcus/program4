import sofia.micro.*;
import sofia.util.Random;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class Hive extends Actor
{
    //~ Fields ................................................................

    private int numberOfBees;
    private int numberOfAct;

    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Hive object.
     */
    public Hive()
    {
        super();        
        numberOfAct = 400;
        numberOfBees = 30;
    }

    
    //~ Methods ...............................................................

    public void addBee()
    {
        Bee bee = new Bee();
        int x = 9;
        int y = Random.generator().nextInt(1,5);
        this.getWorld().add(bee, x, y);

    }

    public int getBees()
    {
        return numberOfBees;
    }

    public void setBees(int n)
    {
        numberOfBees = n;
    }
    
    public void act()
    {
        numberOfAct--;

        if (numberOfAct < 1)
        {
            if (numberOfBees > 0 )
            {
                this.addBee();
                numberOfBees = numberOfBees - 1;
            }
            
            numberOfAct = Random.generator().nextInt(80,400);
        }

    }

}
