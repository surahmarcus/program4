import sofia.micro.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author Sarah Marcus (stmarcus)
 *  @version (2016.10.26)
 */
public class Ant extends Actor
{
    //~ Fields ................................................................

    private int health;  
    private int cost;
    private int turn;

    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Ant object.
     */
    public Ant(int cost1, int health1)
    {
        cost = cost1;
        health = health1;
    }


    //~ Methods ...............................................................
    
    /**
     * Stores ant's health value.
     */
    public int getHealth()
    {
        return health;
    }
    
    public void injure(int n)
    {        
        health = health - n ;
        if (health <= 0)
        {
           this.remove();
        }
            
    }
    
    public int getFoodCost()
    {
        return cost;
    }


}
