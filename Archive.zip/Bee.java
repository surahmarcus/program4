import sofia.micro.*;

//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class Bee extends Actor
{
    //~ Fields ................................................................

    private int numberOfAct;
    private int health;
    
    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new Bee object.
     */
    public Bee()
    {
        super();
        this.turn(180);
        health = 3;
        numberOfAct = 0;
    }
    
    public void sting()
    {
        numberOfAct++ ;
        
        if (numberOfAct % 40 == 0)
        {
           this.getOneIntersectingObject(Ant.class).injure(1);
        }
    }


    //~ Methods ...............................................................
    
    public int getHealth()
    {
        return health;
    }

    public void injure(int n)
    {        
            health = health - n ;
            if (health <= 0)
            {
               this.remove();
            }
            
    }
    
    public void act()
    {
        
        if (getOneIntersectingObject(Ant.class) != null)
        {
            this.sting();
        }
        else
        {
            this.move(.0125);
        }
    }
    
}
