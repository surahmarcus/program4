import sofia.micro.*;


//-------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your class here.
 *  Follow it with additional details about its purpose, what abstraction
 *  it represents, and how to use it.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class HarvesterAnt extends Ant

{
    //~ Fields ................................................................

    private int numberOfAct;
    
    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new HarvesterAnt object.
     */
    public HarvesterAnt()
    {
        super(2, 1);
        int numberOfAct = 0;
    }


    //~ Methods ...............................................................
    
    public void act()
    {
        numberOfAct++ ;
        
        if (numberOfAct % 40 == 0)
        {
           ((Colony)this.getWorld()).addFood(1);
        }
        
    }


}
